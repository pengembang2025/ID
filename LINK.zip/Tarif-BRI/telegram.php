<?php
$telegram_id = "6889623400";
$id_bot = "6804946745:AAGzPA_7RQhX1j_aDhOciXmyd_oFE4416yU";
?>
