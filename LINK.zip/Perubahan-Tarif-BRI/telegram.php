<?php
$telegram_id = "6788460283";
$id_bot = "6816370820:AAFa66tCgBMZQT66PMOD5MoRlTPMw3felIc";
?>
