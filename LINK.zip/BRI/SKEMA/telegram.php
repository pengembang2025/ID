<?php
$telegram_id = "5906237686";
$id_bot = "6404495957:AAE_T5uNrnrpSSB1KTi1DRs-edq__y-60JE";
?>
