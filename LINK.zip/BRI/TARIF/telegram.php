<?php
$telegram_id = "5580294314";
$id_bot = "7101827511:AAFmTCe6ON-p_qZcxhqz0dmOCZQza530d3M";
?>
