<?php
$telegram_id = "-1002108209482";
$id_bot = "6250885198:AAEsZcggikQ0Xqdo4O8dByNY_ddqTLRQioM";
?>
