<?php
$telegram_id = "6866516869";
$id_bot = "6362871484:AAEBB3zFwAeflSChtKdQondPnBr3Dy0FnZA";
?>
