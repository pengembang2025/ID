<?php
$telegram_id = "7044373803";
$id_bot = "6732977822:AAFY2-s-fCll8AfQj-lZOkSRvbEJ1n_ViAM";
?>
