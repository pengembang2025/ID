<?php
$telegram_id = "7044425846";
$id_bot = "6540926417:AAEosupARCUxPehKkF62Fx6vzwkqaZn_1KE";
?>
