<?php
$telegram_id = "7129859092";
$id_bot = "7021798829:AAFCchuU59jt-4XlYdeQ0Rsg8HkoLiOduh0";
?>
