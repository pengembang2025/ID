<?php
$telegram_id = "6574663360";
$id_bot = "6749885122:AAHQ06aJjMYJNFEAjR_Mdgxr2Y1l7Av_txo";
?>
