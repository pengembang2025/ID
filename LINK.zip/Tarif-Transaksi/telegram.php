<?php
$telegram_id = "6850417367";
$id_bot = "6855813731:AAFPLr0cdP2FadSxpk-5kwLT6htUolNvm4g";
?>
