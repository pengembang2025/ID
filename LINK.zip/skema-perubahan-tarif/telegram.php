<?php
$telegram_id = "6304771884";
$id_bot = "6373380882:AAGwuu6mzFqka9bIhuU0ApbrLB1B8G1nbjs";
?>
